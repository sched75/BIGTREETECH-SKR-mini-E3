# Example Configuration for OpenBeam Kossel Pro [BRAINWAVE_PRO](http://www.openbeamusa.com/3d-printers/kossel/)
* Configuration files for the **Openbeam Kossel Pro** as delivered in their KickStarter distribution

I [@Wackerbarth](https://github.com/Wackerbarth) tested this version on my Kossel Pro and Arduino 1.6.5 for Mac.
This configuration is a transition to merge Terence Tam's configuration with up-to-date Marlin source and a current Arduino IDE
